package com.traynotifications.animations;

public enum AnimationType {
    FADE,
    SLIDE,
    POPUP
}
